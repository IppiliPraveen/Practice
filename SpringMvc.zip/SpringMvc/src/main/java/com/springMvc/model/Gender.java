package com.springMvc.model;

public enum Gender {
	MALE,FEMALE
}
