package com.springMvc.Constants;

public interface MvcConstants {
	
	int ZERO=0;
	
	int ONE=1;
	
	String NULL="null";

}
